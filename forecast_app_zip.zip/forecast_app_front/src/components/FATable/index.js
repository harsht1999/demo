
import React, { useEffect, useState } from "react";
import axios from 'axios';
import { Button, Col, Container, Row, Table } from "react-bootstrap";
import { toast } from "react-toastify";
import ExportToExcel from "../ExportToExcel";
import { Trash } from 'react-bootstrap-icons';
import Header from './Header';
import Footer from './Footer';

var jsonData = [];
const FATable = () => {


  const [columns, setColumns] = useState(["Column 1"]);
  const [generating, setGenerating] = useState(true);
  const [readOnly, setReadOnly] = useState(true);
  const [rows, setRows] = useState(0);
  const [rowsData, setRowsData] = useState([]);
  const [modified, setModified] = useState(false);




  const myUrl="http://localhost:8080/api/data";
  const saveData = async () => {
    let flag=true;
    try {
      const loadingToastId = toast.loading('Saving state...', { autoClose: 200 });
      setTimeout(() => {
        toast.dismiss(loadingToastId);
      }, 1000);
      
      const response = await axios.post(myUrl,jsonData);
  
      if (response.status === 201 || response.status === 200) {
        console.log('Data saved successfully:', response.data);
  
      } else {
        console.error('Error saving data:', response.statusText);
      }
    } catch (error) {
      console.error('Error saving data:', error.message);
      toast.error("Error:Cannot perform action:"+error.message);
      flag=false;
    }
    if(flag)toast.success("Saved.");
  };


  const fetchData = async () => {
    let receivedData="";
    try {
      const response = await axios.get(myUrl);
  
      if (response.status === 200) {
        receivedData=response.data;
        jsonData=receivedData;
        setDataFromJson(jsonData);
        
      } else {
        console.log('Error fetching data:', response);
      }
    } catch (error) {
      console.log('Error fetching data:', error.message);
    }
  
  };



  const handleChange = (e, index, index2) => {
    if(index2>=4 && (!isNumeric(e) && e!=""))
    {
      toast.error("Only Numeric values are allowed in Datasets.")
      return;
    }
    const fields = rowsData[index].map((r, j) => (j === index2 ? e : r));
    setRowsData(rowsData.map((rw, i) => (i === index ? fields : rw)));
  };

  const addRow = () => {
    setModified(true);
    setRows((prevRows) => prevRows + 1);
    let array = [""];
    for (let i = 1; i < columns.length; i++) {
      array.push("");
    }
    setRowsData((prevRowsData) => [...prevRowsData, array]);
  };

  const deleteRow = (index) => {
    if(rowsData.length==1 && columns.length>4) 
    {
      toast.dark("Please delete all dataset before deleting the last row.");
      return;
    }
    setModified(true);
    setRows((prevRows) => prevRows - 1);
    setRowsData((prevRowsData) => prevRowsData.filter((row, i) => i !== index));
  };

  const addColumn = () => {
    if(rowsData.length==0) 
    {
      toast.dark("Please add a data row first.");
      return;
    }

    setModified(true);
    if (columns.length === 10) {
      return toast.dark("You can add max. 10 columns!");
    }

    let lastColumnData = rowsData.map((row) => row[row.length - 1]);

    setColumns((prevColumns) => [
      ...prevColumns,
      `Year: ${prevColumns.length-4 + 1}`,
    ]);
    if(columns.length==4)
    {
      setRowsData((prevRowsData) =>
      prevRowsData.map((row, index) => [...row, "" || ""])
    );
      return;
    }
    setRowsData((prevRowsData) =>
      prevRowsData.map((row, index) => [...row, lastColumnData[index] || ""])
    );
  };

  const deleteColumn = (index) => {

    setModified(true);
    if (columns.length === 1) {
      return toast.dark("There Should be atleast 1 column!");
    }
    setColumns((prevColumns) =>
      prevColumns.filter((col) => prevColumns.indexOf(col) !== index)
    );

    setRowsData((prevRowsData) =>
      prevRowsData.map((row) => {
        const filteredRows = row.filter((rw, i) => i !== index);
        return filteredRows;
      })
    );
  };

  const saveState = () => {
    const data = [];

    for (let rowIndex = 0; rowIndex < rowsData.length; rowIndex++) {
      const row = rowsData[rowIndex];
      const obj = {};
      for (let colIndex = 0; colIndex < columns.length; colIndex++) {
        const col = columns[colIndex];
        obj[col] = row[colIndex];
      }
      data.push(obj);
    }
    
    jsonData=data;
    //alert(JSON.stringify(jsonData));
    saveData();
};

  const isNumeric = (value) => !isNaN(parseFloat(value)) && isFinite(value);

  const calculateColumnSum = (columnIndex) => {
    return rowsData.reduce((sum, row) => {
      const value = row[columnIndex];
      return isNumeric(value) ? sum + parseFloat(value) : sum;
    }, 0);
  };


  const setDataFromJson = (jsonData) => {
    const newColumns = Object.keys(jsonData[0]);
    setColumns(newColumns);
  
    const newRowsData = jsonData.map((obj) => Object.values(obj));
    setRowsData(newRowsData);
  };
  
  
  useEffect(() => {
    fetchData();
    if (!modified) {
      const initialColumns = ["col1", "col2", "col3", "col4"];
      setColumns([...initialColumns, ...columns.slice(initialColumns.length)]);
    }
    setGenerating(false);
  }, []);
 

  const setHeader=(ev,index) =>{
    let headerValue=ev.target.value;
    if(!headerValue.startsWith("Year:") && index>3){
    toast.error("Dataset should be in format-> Year:****");
    return;
  }
  setColumns(
    columns.map((coln, id) =>
      id === index ? ev.target.value : coln
    )
  );
};


  return (
    <Container fluid>
    <Header/>
      <br></br>
      <Row className="mt-5 mb-3">
        <Col md={3}>
        </Col>
        <Col
          md={6}
          className="d-flex align-items-center justify-content-end"
          style={{ marginLeft: "auto", marginRight: "70px" }}
        >
          <Button type="button" onClick={saveState} variant="success">
            Save State
          </Button>
          &nbsp;&nbsp;
          <ExportToExcel columns={columns} rowsData={rowsData} />
        </Col>
      </Row>
      <Row>
        <Col md={12} className="px-5">
          {!generating ? (
            <>
              <Table responsive striped className="my-5 h-100">
                <thead>
                  <tr>
                    <th></th>
                    {columns.map((col, index) => (
                      <th key={index + 999999}>

                        {index >= 4 && (
                            <Button
                          type="button"
                          className="btn-block w-100"
                          onClick={() => deleteColumn(index)}
                          variant="outline-danger"
                          size="sm"
                        >
                          <Trash />
                        </Button>
                        )}
                      </th>
                    ))}
                    <th></th>
                  </tr>
                  <tr className="text-white">
                    <th
                      scope="col"
                      style={{ "background-color": "rgb(102, 0, 204)","border":"4px solid black" }}
                      className="d-flex align-items-center text-white justify-content-center py-3 pb-2 border-0"
                    >
                      S.No.
                    </th>
                    {columns.map((col, index) => (
                      <th key={index} scope="col">
                        <input
                          type="text"
                          className="form-control border-0 text-center text-white border-1"
                          style={{ "background-color": "rgb(102, 0, 204)"}}
                          readOnly={readOnly}
                          onFocus={() => setReadOnly(false)}
                          onBlur={() => setReadOnly(true)}
                          value={columns[index]}
                          onChange={(ev)=>setHeader(ev,index)}
                        />
                      </th>
                    ))}
                    <th className="text-center">
                      <Button
                        type="button"
                        onClick={addColumn}
                        className="text-white"
                        style={{"background-color": "#400080"}}
                        size="sm"
                      >
                        Add Data Set
                      </Button>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rowsData.length > 0 ? (
                    <>
                      {rowsData.map((data, index) => (
                        <tr key={index + 5}>
                          <td className="text-center">{index + 1}</td>
                          {data.map((row, index2) => (
                            <td key={index2 + 988}>
                              <input
                                type="text"
                                className="form-control text-center"
                                placeholder={`Enter value`}
                                value={rowsData[index][index2]}
                                onChange={(e) =>
                                  handleChange(e.target.value, index, index2)
                                }
                              />
                            </td>
                          ))}
                          <td className="text-center">
                            <Button
                              type="button"
                              onClick={() => deleteRow(index)}
                              variant={"outline-danger"}
                              size="sm"
                            >
                              <Trash/>
                            </Button>
                          </td>
                        </tr>
                      ))}

                      <tr>
                        <td className="text-center font-weight-bold">Total</td>
                        {columns.map((col, index) => (
                          <td key={index + 888} className="text-center">
                            {index < 4 ? '' : (isNumeric(rowsData[0][index])
                              ? calculateColumnSum(index)
                              : "-")}
                          </td>
                        ))}
                        <td className="text-center"></td>
                      </tr>
                      <tr>
                        <th colSpan={columns.length + 2} className="pt-1">
                          <Button
                            type="button"
                            onClick={addRow}
                            className="w-100"
                            style={{"background-color": "#9933ff"}}
                            >
                            Add Data Row
                          </Button>
                        </th>
                      </tr>
                    </>
                  ) : (
                    <>
                      <tr>
                        <th colSpan={columns.length + 2}>
                          <Button
                            type="button"
                            onClick={addRow}
                            className="w-100"
                            style={{"background-color": "#9933ff"}}
                          >
                            Add Data Row
                          </Button>
                        </th>
                      </tr>
                    </>
                  )}
                </tbody>
              </Table>
            </>
          ) : (
            <h1 className="text-center my-5">Generating...</h1>
          )}
        </Col>
      </Row>
    </Container>
  );
};

export default FATable;
