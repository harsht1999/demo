import React from 'react';
import './footer.css';
const Footer = () => {
    return (
        <div className='container'>
            <div className='footer'>
            © Copyright - @My_Forecasting_App 2024  
            </div>
        </div>
    );
};

export default Footer;