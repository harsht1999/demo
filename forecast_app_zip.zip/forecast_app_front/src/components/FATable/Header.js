import './header.css';

const Header = () => {
return (
    <div className="my-header">
        <span className="navbar-name "><b>My Forecasting App</b></span>
    </div>
    );
  };
  export default Header;