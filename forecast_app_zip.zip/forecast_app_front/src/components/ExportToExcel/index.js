import React from "react";

import ReactHTMLTableToExcel from "react-html-table-to-excel";

const ExportToExcel = ({ columns, rowsData }) => {
  const isNumeric = (value) => !isNaN(parseFloat(value)) && isFinite(value);
  const calculateColumnSum = (columnIndex) => {
    return rowsData.reduce((sum, row) => {
      const value = row[columnIndex];
      return isNumeric(value) ? sum + parseFloat(value) : sum;
    }, 0);
  };

  return (
    <>
      <ReactHTMLTableToExcel
        id="test-table-xls-button"
        className="download-table-xls-button"
        table="table-to-xls"
        filename="My Table Data"
        sheet="table"
        buttonText="Save as Excel"
      />
      <table id="table-to-xls" style={{ display: "none" }}>
        <tr>
          <th>s no</th>
          {columns.map((col, id) => (
            <th key={id * 5}>{col}</th>
          ))}
        </tr>
        {rowsData.map((row, id) => (
          <tr key={id * 99}>
            <td key={55}>{id + 1}</td>
            {row.map((rw, i) => (
              <td key={i * 88}>{rw}</td>
            ))}
          </tr>
        ))}
        <tr>
          <td className="text-center font-weight-bold">Total</td>
          {columns.map((col, index) => (
             <td key={index + 888} className="text-center">
              {index < 4 ? '' : (isNumeric(rowsData[0][index])
                ? calculateColumnSum(index)
                : "-")}
            </td>
          ))}
          <td className="text-center"></td>
        </tr>
      </table>
    </>
  );
};

export default ExportToExcel;
