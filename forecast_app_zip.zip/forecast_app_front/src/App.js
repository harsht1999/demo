import React, { useState } from "react";
import { BrowserRouter as Router, Routes,Route, Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";

import "./App.css";

import FATable from "./components/FATable";

function App() {
  return (
     <Router>
      <ToastContainer />
      <Routes>
      <Route
            path="/"
            element={<FATable/>}
          />
      </Routes>
      </Router>    
    );
}


export default App;
