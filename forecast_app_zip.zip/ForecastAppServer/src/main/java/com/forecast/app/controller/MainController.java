package com.forecast.app.controller;

import java.net.URI;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.forecast.app.service.TableDataService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api")
@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
public class MainController {
	@Autowired
	TableDataService tableDataService;
	
	@PostMapping(
			path = "/data",
			produces = "application/json")
	@SuppressWarnings("unchecked")
		public void saveData(@RequestBody String str)
		{
			tableDataService.add(str);
		}

	@GetMapping(
			path = "/data",
			produces = "application/json")

		public ResponseEntity<String> getData()
		{
			return new ResponseEntity(tableDataService.get(),HttpStatus.OK);					
		}

}
