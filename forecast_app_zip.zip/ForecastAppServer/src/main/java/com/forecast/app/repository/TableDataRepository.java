package com.forecast.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;

import com.forecast.app.entity.TableData;

@Repository
public interface TableDataRepository extends JpaRepository<TableData, Integer> {
	
}