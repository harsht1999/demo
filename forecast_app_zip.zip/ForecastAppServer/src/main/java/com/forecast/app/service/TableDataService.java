package com.forecast.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.forecast.app.entity.TableData;
import com.forecast.app.repository.TableDataRepository;
@Service
public class TableDataService {

	@Autowired
	TableDataRepository tdr;
	
	
	public void add(String data)
	{
		TableData tableData=new TableData(1,data);
		try {
			tdr.save(tableData);
		}
		catch(Exception e)
		{
			System.out.println(e+"-------------------------------------");
		}
	}
	
	public String get()
	{
		String data=tdr.getById(1).getData();
		return data;
	}
	

}
