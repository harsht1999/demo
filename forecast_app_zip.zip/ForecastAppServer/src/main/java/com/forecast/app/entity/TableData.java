package com.forecast.app.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.util.*;
@Entity
public class TableData {
	@Id
	private Integer id;
	private String data;
	
	public TableData() {
	}
	
	public TableData(Integer id, String data) {
		super();
		this.id = id;
		this.data = data;
	}

	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	
}
